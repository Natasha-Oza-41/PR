// index.js
const dbConnect = require('./monogodb');
const express = require('express');
const app = express();
app.use(express.json());

app.get('/', async (req, res) => {
    let collection = await dbConnect();
    let result = await collection.find().toArray();  
    res.send(result);
});

app.post('/', async (req, res) => {
    let collection = await dbConnect();
    let result = await collection.insertOne(req.body);
    res.send("Inserted Successfully!!");
});

app.put('/:name', async (req, res) => {
    let collection = await dbConnect();
    let result = await collection.updateOne({name:req.params.name},{$set:req.body});
    res.send("Updated Successfully!!");
});

app.delete('/:name', async (req, res) => {
    let collection = await dbConnect();
    let result = await collection.deleteOne({name:req.params.name});
    res.send("Deleted Successfully!!");
});

app.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
