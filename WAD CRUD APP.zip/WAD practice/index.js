const express = require('express');
const mongoose = require('mongoose');
const app = express();
const body_parser = require('body-parser');
const Student = require('./StudentModel');

app.use(body_parser.json());
app.use(body_parser.urlencoded({ extended: true }));


mongoose.connect("mongodb://localhost:27017/WAD")
    .then(()=> console.log("Connected to mongodb"))
    .catch(err => console.error("Error occurred : " , err));

app.get('/' , async (req , res)=>{
    const students = await Student.find();
    res.send(students);
});

app.post('/add-student' , async (req , res) => {
    const {name , age , email , course} = req.body;
    const newstudent =  await Student.create({name , age , email , course});
    res.send("Student Added successfully");
});


app.put('/update-student/:id' , async (req , res) => {
    const {id} = req.params;
    const {name , age , email , course} = req.body;
    try{
        const updateStudent = await Student.findByIdAndUpdate(id , {name , age , email , course} , {new : true} );

        if(!updateStudent){
            res.status(400).send("Student not found");
        }

        res.send("Student Updated successfully");
    }
    catch(err){
        res.status(500).send("Error updating student");
    }

});

app.delete('/delete-student/:id' , async (req , res) => {
   const {id} = req.params;
    try{
        const deletedstudent = await Student.findByIdAndDelete(id );
        if(!deletedstudent){
            res.status(400).send("Student not found");
        }

        res.send(`${deletedstudent.name} has been deleted successfully`);
    }
    catch(err){
        res.status(500).send("Error updating student");
    }

});
app.listen(3000 , ()=>{
    console.log("Server is Running");
})


// MONGO_URI=mongodb://localhost:27017/StudentsApp